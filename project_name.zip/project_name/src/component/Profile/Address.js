const MyComponent = (props) => { ... }

MyComponent.displayName = 'Ariana'