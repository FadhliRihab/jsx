const MyComponent = (props) => { ... }

MyComponent.displayName = 'Rihab Fadhli'